package com.buckzy.registration.module.portlet.constants;

/**
 * @author sandip
 */
public class BuckzyRegistrationModulePortletKeys {

	public static final String BuckzyRegistrationModule = "BuckzyRegistrationModule";
	public static final String PORTLET_ID="com_buckzy_registration_module_portlet_portlet_BuckzyRegistrationModulePortlet";

}