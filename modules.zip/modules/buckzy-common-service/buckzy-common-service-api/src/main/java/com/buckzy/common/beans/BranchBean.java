package com.buckzy.common.beans;

public class BranchBean {
	private int branchId;
	private int bankId;
	private String cityName;
	private String branchRtngnr;
	private String branchDes;
	private String branchAddrline;
	private String branchAddrline2;
	private int cityId;
	private String stateCd;
	private String cntryCd;
	private String swiftBic;
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public int getBankId() {
		return bankId;
	}
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}
	public String getBranchRtngnr() {
		return branchRtngnr;
	}
	public void setBranchRtngnr(String branchRtngnr) {
		this.branchRtngnr = branchRtngnr;
	}
	public String getBranchDes() {
		return branchDes;
	}
	public void setBranchDes(String branchDes) {
		this.branchDes = branchDes;
	}
	public String getBranchAddrline() {
		return branchAddrline;
	}
	public void setBranchAddrline(String branchAddrline) {
		this.branchAddrline = branchAddrline;
	}
	public String getBranchAddrline2() {
		return branchAddrline2;
	}
	public void setBranchAddrline2(String branchAddrline2) {
		this.branchAddrline2 = branchAddrline2;
	}
	public int getCityId() {
		return cityId;
	}
	public void setCityId(int cityId) {
		this.cityId = cityId;
	}
	public String getStateCd() {
		return stateCd;
	}
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}
	public String getCntryCd() {
		return cntryCd;
	}
	public void setCntryCd(String cntryCd) {
		this.cntryCd = cntryCd;
	}
	public String getSwiftBic() {
		return swiftBic;
	}
	public void setSwiftBic(String swiftBic) {
		this.swiftBic = swiftBic;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
	
}
