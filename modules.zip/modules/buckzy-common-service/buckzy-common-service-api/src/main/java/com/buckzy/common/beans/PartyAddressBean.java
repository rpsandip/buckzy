package com.buckzy.common.beans;

public class PartyAddressBean {
	private  long addrtypeid;
	private String postaddr;
	private String streetnm;
	private String bldgnr;
	private String townnm;
	private String state;
	private String cntrycd;
	private String zipcd;
	private String prefflg;
	private String moddt;
	private String modby;
	
	public PartyAddressBean(){
		
	}

	public long getAddrtypeid() {
		return addrtypeid;
	}

	public void setAddrtypeid(long addrtypeid) {
		this.addrtypeid = addrtypeid;
	}

	public String getPostaddr() {
		return postaddr;
	}

	public void setPostaddr(String postaddr) {
		this.postaddr = postaddr;
	}

	public String getStreetnm() {
		return streetnm;
	}

	public void setStreetnm(String streetnm) {
		this.streetnm = streetnm;
	}

	public String getBldgnr() {
		return bldgnr;
	}

	public void setBldgnr(String bldgnr) {
		this.bldgnr = bldgnr;
	}

	public String getTownnm() {
		return townnm;
	}

	public void setTownnm(String townnm) {
		this.townnm = townnm;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCntrycd() {
		return cntrycd;
	}

	public void setCntrycd(String cntrycd) {
		this.cntrycd = cntrycd;
	}

	public String getZipcd() {
		return zipcd;
	}

	public void setZipcd(String zipcd) {
		this.zipcd = zipcd;
	}

	public String getPrefflg() {
		return prefflg;
	}

	public void setPrefflg(String prefflg) {
		this.prefflg = prefflg;
	}

	public String getModdt() {
		return moddt;
	}

	public void setModdt(String moddt) {
		this.moddt = moddt;
	}

	public String getModby() {
		return modby;
	}

	public void setModby(String modby) {
		this.modby = modby;
	}
	
	
	
}
