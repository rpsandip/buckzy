create index IX_45643715 on BUCKZY_CustomUser (mobileNo[$COLUMN_LENGTH:75$], mobCountryCode[$COLUMN_LENGTH:75$]);
create index IX_FFA51CA1 on BUCKZY_CustomUser (userId);