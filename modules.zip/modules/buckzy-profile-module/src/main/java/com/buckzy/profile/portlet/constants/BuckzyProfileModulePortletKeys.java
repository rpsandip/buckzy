package com.buckzy.profile.portlet.constants;

/**
 * @author sandip
 */
public class BuckzyProfileModulePortletKeys {

	public static final String BuckzyProfileModule = "BuckzyProfileModule";
	public static final String PORTLET_ID="com_buckzy_profile_portlet_portlet_BuckzyProfileModulePortlet";

}