package com.buckzy.dashboard.portlet.constants;

/**
 * @author sandip
 */
public class DashboardModulePortletKeys {

	public static final String DashboardModule = "DashboardModule";

}