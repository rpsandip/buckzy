package com.buckzy.send.money.portlet.constants;

/**
 * @author sandip
 */
public class BuckzySendMoneyControllerPortletKeys {

	public static final String BuckzySendMoneyController = "BuckzySendMoneyController";
	public static final String PORTLET_ID="com_buckzy_send_money_portlet_portlet_BuckzySendMoneyControllerPortlet";

}