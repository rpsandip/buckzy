package google.login.web.constants;

/**
 * @author sandip
 */
public class GoogleLoginWebPortletKeys {

	public static final String GoogleLoginWeb = "GoogleLoginWeb";

}