package com.buckzy.sms.verification.portlet.constants;

/**
 * @author sandip
 */
public class BuckzySMSVerificationModulePortletKeys {

	public static final String BuckzySMSVerificationModule = "com_buckzy_sms_verification_portlet_portlet_BuckzySMSVerificationModulePortlet";
	public static final String PORTLET_ID = "com_buckzy_sms_verification_portlet_portlet_BuckzySMSVerificationModulePortlet";

}