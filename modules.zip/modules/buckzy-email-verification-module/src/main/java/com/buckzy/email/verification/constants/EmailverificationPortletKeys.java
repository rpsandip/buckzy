package com.buckzy.email.verification.constants;

/**
 * @author sandip
 */
public class EmailverificationPortletKeys {

	public static final String Emailverification = "Emailverification";
	public static final String PORTLET_ID = "com_buckzy_email_verification_portlet_EmailverificationPortlet";

}