package com.buckzy.facebook.login.portlet.constants;

/**
 * @author sandip
 */
public class FacebookLoginPortletKeys {

	public static final String FacebookLogin = "FacebookLogin";

}